#include "derived1.h"
#include <iostream>

Derived1::Derived1(std::ostream &out)
{
	std::cout << "Derived1 constructed\n";
}