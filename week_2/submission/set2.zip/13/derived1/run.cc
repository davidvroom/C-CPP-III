#include "derived1.h"
#include <iostream>

void Derived1::run()
{
	std::cout << "run called from Derived1\n";
}