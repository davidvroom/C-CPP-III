#include "abc.h"

ABC::~ABC()
{}
