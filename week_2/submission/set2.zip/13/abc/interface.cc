#include "abc.h"

void ABC::interface()
{
	// we don know how to do this
	//this->run();
	//run();
}