#include "derived2.h"
#include <iostream>

void Derived2::run()
{
	std::cout << "run called from Derived2\n";
}