#include "derived2.h"

#include <iostream>

Derived2::Derived2(std::istream &in, std::ostream &out)
{
	std::cout << "Derived2 constructed\n";
}