#include "intvalue/intvalue.h"
#include "doublevalue/doublevalue.h"

#include <iostream>

using namespace std;

int main()
{
	cout << IntValue{} << '\n';
	cout << DoubleValue{} << '\n';
}
