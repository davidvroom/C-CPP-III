#include "parser.ih"

void Parser::setDeg()
{
	d_angle = DEG;
	prompt();
}