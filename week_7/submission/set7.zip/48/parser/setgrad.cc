#include "parser.ih"

void Parser::setGrad()
{
	d_angle = GRAD;
	prompt();
}