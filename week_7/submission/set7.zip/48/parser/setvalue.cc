#include "parser.ih"

RuleValue Parser::setValue(double const arg)
{
    return RuleValue(arg);
}