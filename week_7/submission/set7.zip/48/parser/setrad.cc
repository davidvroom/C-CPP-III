#include "parser.ih"

void Parser::setRad()
{
	d_angle = RAD;
	prompt();
}