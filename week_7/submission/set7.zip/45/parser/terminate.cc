#include "parser.ih"

void Parser::terminate()
{
	ACCEPT();
}