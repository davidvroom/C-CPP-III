#include "parser/parser.h"

int main()
{
	Parser parser;
	parser.parse();
}