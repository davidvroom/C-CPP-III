#include "parser.ih"

Parser::Parser()
{
	cout << "> ";
}