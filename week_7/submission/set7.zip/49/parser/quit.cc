#include "parser.ih"

void Parser::quit()
{
	ACCEPT();
}