#include <iostream>
#include "bin.h"

using namespace std;

int main()
{
    cout << Bin<5>::value  << '\n' <<
            Bin<27>::value << '\n';
}
